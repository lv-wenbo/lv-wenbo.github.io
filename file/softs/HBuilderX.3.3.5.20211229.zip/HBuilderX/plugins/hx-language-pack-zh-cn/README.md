#  适用于 HBuilderX 的中文（简体）语言包

此中文（简体）语言包为 HBuilderX 提供本地化界面。


## 参与

如果你想提供或改进翻译，请参阅[社区本地化页面](https://www.dcloud.io)并获取更多信息。

## 许可证

源代码和字符串使用[MIT](https://www.dcloud.io/language-pack/LICENSE.md)许可进行授权。

## 感谢

此中文（简体）语言包是“来自社区，奉献社区”的社区本地化工作的成果。

特别感谢社区中每一位向这个项目做出贡献的朋友。


#  Chinese (Simplified) Language Pack for HBuilderX

Chinese (Simplified) Language Pack provides localized UI experience for HBuilderX.

## Contributing

If you'd like to participate in the effort either to contribue translation or improve translation, see [community localization page](https://www.dcloud.io) for more information.

## License

The source code and strings are licensed under the [MIT](https://www.dcloud.io/language-pack/LICENSE.md) license.

## Credits

Chinese (Simplified) Language Pack is brought to you through "By the community, for the community" community localization effort.

Special thanks to community contributors for making it available.

