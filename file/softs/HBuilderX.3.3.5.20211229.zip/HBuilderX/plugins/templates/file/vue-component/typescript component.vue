<template>
	<view>

	</view>
</template>

<script lang="ts">
	export default {
		name:"<%fileName%>",
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>
